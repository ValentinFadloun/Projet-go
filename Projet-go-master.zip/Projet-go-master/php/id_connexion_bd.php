<?php

//parametres de connexion à la base de données
$db_username = "vn934281";
$db_password = "vn934281";
//en private html
//$db = "mysql:dbname=val;host=localhost";
//en public html
  $db = "mysql:dbname=vn934281;host=172.31.21.41";
?>
